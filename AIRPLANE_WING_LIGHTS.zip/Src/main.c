/*
Program :Airplane wing Lights blinking Delays:
					USER LED1 (GREEN): ON (50msec), OFF (50msec), ON (50msec), OFF (150msec) periodically.
					USER LED2 (RED): ON (50msec), OFF (250msec), ON (50msec), OFF (500msec) periodically.
Board : Raayanmini board
Version : 4.0
controller : STM32F401RBT6
Pins used:
PB13 - RED LED
PB14 - GREEN LED
*/



#define RCC_AHB1ENR *(int *)0x40023830
#define GPIOB_MODER *(int *)0x40020400
#define GPIOB_ODR *(int *)0x40020414


void delay(int n)
{
	//1668 delay for 1msec
	int i;
	for(i=0;i<1668 * n;i++);
}

int main()
{
	//phase 1: Device Initialization



	//phase 2: Device Configuration

	RCC_AHB1ENR |= (0x02);	//enable the port B clock
	GPIOB_MODER |= 0x14000000;	//load 0101 to 29-26 bits of portB to change it o/p direction mode


	while(1)
	{
		///phase 3:Device Operation
		GPIOB_ODR &= ~(0x1<<14);	//clear the 14th bit to ON GREEN LED
		delay(50);								//delay of 50 msec
		GPIOB_ODR |= 0X1<<14;			//set the 14th bit to OFF GREEN LED
		delay(50);								//delay of 50 msec
		GPIOB_ODR &= ~(0x1<<14);	//clear the 14th bit to ON GREEN LED
		delay(50);								//delay of 50 msec
		GPIOB_ODR |= 0X1<<14;			//set the 14th bit to OFF GREEN LED
		delay(150);								//delay of 150 msec

		GPIOB_ODR &= ~(0x1<<13);	//clear the 13th bit to ON RED LED
		delay(50);								//delay of 50 msec
		GPIOB_ODR |= 0X1<<13;			//set the 13th bit to OFF RED LED
		delay(250);								//delay of 250 msec
		GPIOB_ODR &= ~(0x1<<13);	//clear the 13th bit to ON RED LED
		delay(50);								//delay of 50 msec
		GPIOB_ODR |= 0X1<<13;			//clear the 13th bit of OFF RED LED
		delay(500);								//delay of 500 msec

	}
}
