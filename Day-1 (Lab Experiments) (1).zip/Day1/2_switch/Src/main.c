
//BASE ADDRESSES OF RCC
#define RCC_BASEADDR 0x40023800

//BASE ADDRESSES OF GPIOS
#define GPIOB_BASEADDR 0x40020400
#define GPIOC_BASEADDR 0x40020800

//PHYSICAL ADDRESSES OF RCC
#define RCC_AHB1ENR  *(int*)(RCC_BASEADDR + 0X30)

//PHYSICAL ADDRESSES OF GPIOB
#define GPIOB_MODER   *(int*)(GPIOB_BASEADDR + 0x00)		//OFFSET IS 0X00
#define GPIOB_ODR     *(int*)(GPIOB_BASEADDR + 0x14)


//PHYSICAL ADDRESSES OF GPIOC
#define GPIOC_MODER   *(int*)(GPIOC_BASEADDR + 0x00)		//OFFSET IS 0X00
#define GPIOC_PUPDR   *(int*)(GPIOC_BASEADDR + 0x0c)		//OFFSET IS 0X0C
#define GPIOC_IDR     *(int*)(GPIOC_BASEADDR + 0X10)		//OFFSET IS 0X10

int main()
{
	//Phase 1: Device Initialization
	RCC_AHB1ENR |= ((0x3) << 1);

	//Phase 2: Device Configuration
	GPIOB_MODER &= ~((0x03) << 26);
	GPIOB_MODER |= ((0x01) << 26);
	GPIOC_PUPDR |= ((0x01) << 20);

	while(1)
	{
		//Phase 3: Device operation
		while (!(GPIOC_IDR & 0x1<<10))	//checking the switch is pressed or not
		{
			GPIOB_ODR &= ~(0x01<<13);	//turn ON the RED LED
		}
		GPIOB_ODR |= 0x1<<13;	//Turn OFF the RED LED
	}
}
