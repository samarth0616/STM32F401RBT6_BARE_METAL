#include "systicktimer.h"
#include "LCD.h"
#include "stm32401rbt6.h"
int main()
  {
	systick_config();

	RCC_AHB1ENR |= (0x1<<1); //intialization 0f port b for clock enable
GPIOB_MODER &= (0XFFFCF000); //Clear '00' in 0,1,2,3,4,5,8 bits of port B 
GPIOB_MODER |= (0x00010555);  //load '01' in 0,1,2,3,4,5,8 bits of port B
GPIOB_ODR &=(~(0X1<<5));	//R/W clear 5 bit to write mode

 KM_LCD_Init();
 KM_LCD_Write_Cmd(0x80);//display in first 16 bit
KM_LCD_Write_str("KERNEL MASTERS");
KM_LCD_Write_Cmd(0xC0);//display in first 16 bit
KM_LCD_Write_str("BENGALURU");
      while(1)
      {
          ;
      }
}

