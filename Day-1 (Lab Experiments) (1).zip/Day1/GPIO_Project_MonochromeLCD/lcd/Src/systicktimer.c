#include "stm32401rbt6.h"
#include "systicktimer.h"
#include "LCD.h"
void systick_config(void)
{
STK_CTRL |= (0x1<<2); //set 2 bit to set AHB in clk_source
STK_CTRL  &= ~(0x1<<1); //clear 1 bit
}
void delay(int n)
{
STK_LOAD =16000*n;
STK_CTRL |= (0x1<<0);
while(1)
{
if(STK_CTRL & (0X1<<16))
{
break;
}
}
STK_VAL =0X1233;
}


