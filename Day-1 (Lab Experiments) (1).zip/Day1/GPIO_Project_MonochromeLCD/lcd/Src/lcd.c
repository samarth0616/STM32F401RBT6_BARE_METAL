#include "systicktimer.h"
#include "LCD.h"
#include "stm32401rbt6.h"
//Write Higher Nibble data in LCD //

void write_high_nibble(unsigned char data)
{	
	GPIOB_ODR &=~(0x0F);//
    GPIOB_ODR |=(data>>4)&(0x0F);    //enable lcd
	GPIOB_ODR |= (0x1<<8);         //set 8 bit
	delay (05);
	GPIOB_ODR &=~(0x1<<8);           //clear 8 bit
}
//Write lower Nibble data in LCD
void write_low_nibble( unsigned char data )
{
	GPIOB_ODR&=~(0x0F);
	GPIOB_ODR|=(data)&(0x0F);       //enable lcd
	GPIOB_ODR |= (0x1<<8);          //set 8 bit
	delay (05);
	GPIOB_ODR &= ~(0x1<<8);         //clear 8 bit
}

	void KM_LCD_Init()
{
	//LCD initialization
	//LCD POWER ON
	delay(20);
	KM_LCD_Write_Cmd(0x33);
	delay(10);
	 KM_LCD_Write_Cmd(0x32);
	 KM_LCD_Write_Cmd(0x0C);
	 KM_LCD_Write_Cmd(0x01);
	//LCD initialization end
}
	//Write LCD command
void KM_LCD_Write_Cmd( unsigned char ch)
{
	
	GPIOB_ODR&=~(0x1<<4);       // clear 4 bit
	write_high_nibble(ch);
	write_low_nibble(ch);
}
//write LCD DATA(single character)
	void KM_LCD_Write_Data( unsigned char ch)
	{
		GPIOB_ODR |=(0x1<<4);      //set 4 bit
				
	 write_high_nibble(ch);
		write_low_nibble(ch);
	
}
	//write LCD DATA(multiple character)
	void KM_LCD_Write_str(char *str)
	{
		int i;
	for(i=0;str[i]!=0;i++)
{
	KM_LCD_Write_Data(str[i]);
}
}

