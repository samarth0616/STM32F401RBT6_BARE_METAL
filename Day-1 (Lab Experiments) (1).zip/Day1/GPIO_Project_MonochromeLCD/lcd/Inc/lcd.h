void write_high_nibble( unsigned char data );
void write_low_nibble( unsigned char data );
void KM_LCD_Init(void);
void KM_LCD_Write_Cmd( unsigned char );
void KM_LCD_Write_Data( unsigned char);
void KM_LCD_Write_str(char *);
