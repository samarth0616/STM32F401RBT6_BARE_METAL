#define GPIOB_MODER (*(int *)(0x40020400))
#define GPIOB_ODR     (*(int *)(0x40020414))
#define RCC_AHB1ENR   (*(int *)(0x40023830))

