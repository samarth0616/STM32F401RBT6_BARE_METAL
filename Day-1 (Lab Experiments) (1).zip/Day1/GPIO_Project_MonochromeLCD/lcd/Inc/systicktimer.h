#define STK_LOAD       *((int *)0xE000E014)
#define STK_VAL       (*(int *)(0xE000E018))
#define STK_CTRL       *((int *)0xE000E010)
	void delay(int);
void systick_config(void);

