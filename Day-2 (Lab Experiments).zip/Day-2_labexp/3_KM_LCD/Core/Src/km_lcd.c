/*
 * km_lcd.c
 *
 *  Created on: Oct 10, 2025
 *      Author: bhargavasai
 */

#include "km_lcd.h"
#include "main.h"



void KM_Lcd_Init(void)
{
	HAL_GPIO_WritePin(GPIOB, LCD_RW_Pin, GPIO_PIN_RESET);  // LCD is in Write mode
	HAL_Delay(50);
	KM_Lcd_Write_Cmd(0x33);
	HAL_Delay(50);
	KM_Lcd_Write_Cmd(0x32);
	KM_Lcd_Write_Cmd(0x0C);
	KM_Lcd_Write_Cmd(0x01);
}


static void write_higher_nibble(char data)
{
	data = (data >> 4);

	HAL_GPIO_WritePin(GPIOB, LCD_D7_Pin, (data & (0x08)));
	HAL_GPIO_WritePin(GPIOB, LCD_D6_Pin, (data & (0x04)));
	HAL_GPIO_WritePin(GPIOB, LCD_D5_Pin, (data & (0x02)));
	HAL_GPIO_WritePin(GPIOB, LCD_D4_Pin, (data & (0x01)));


	HAL_GPIO_WritePin(GPIOB, LCD_EN_Pin, GPIO_PIN_SET);  // For Enable
	HAL_Delay(10);
	HAL_GPIO_WritePin(GPIOB, LCD_EN_Pin, GPIO_PIN_RESET);  // For Enable
}

static void write_lower_nibble(char data)
{
	data = (data & (0x0F));

	HAL_GPIO_WritePin(GPIOB, LCD_D7_Pin, (data & (0x08)));
	HAL_GPIO_WritePin(GPIOB, LCD_D6_Pin, (data & (0x04)));
	HAL_GPIO_WritePin(GPIOB, LCD_D5_Pin, (data & (0x02)));
	HAL_GPIO_WritePin(GPIOB, LCD_D4_Pin, (data & (0x01)));

	HAL_GPIO_WritePin(GPIOB, LCD_EN_Pin, GPIO_PIN_SET);  // For Enable
	HAL_Delay(10);
	HAL_GPIO_WritePin(GPIOB, LCD_EN_Pin, GPIO_PIN_RESET);  // For Enable
}

void KM_Lcd_Write_Cmd(char data)
{
	HAL_GPIO_WritePin(GPIOB, LCD_RS_Pin, GPIO_PIN_RESET);  // For Command
	write_higher_nibble(data);
	write_lower_nibble(data);
}

void KM_Lcd_Write_Data(char data)
{
	HAL_GPIO_WritePin(GPIOB, LCD_RS_Pin, GPIO_PIN_SET);  // For Data
	write_higher_nibble(data);
	write_lower_nibble(data);
}

void KM_Lcd_Write_Str(char *str)
{
	while(*str)
	{
		KM_Lcd_Write_Data(*str);
		str++;
	}
}




