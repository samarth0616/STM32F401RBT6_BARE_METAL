/*
 * km_lcd.h
 *
 *  Created on: Oct 10, 2025
 *      Author: bhargavasai
 */

#ifndef INC_KM_LCD_H_
#define INC_KM_LCD_H_
/*
 LCD_D4_Pin|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin
                          |LCD_RS_Pin|LCD_RW_Pin|LCD_EN_Pin
 */

void KM_Lcd_Init(void);

void KM_Lcd_Write_Cmd(char);

void KM_Lcd_Write_Data(char );

void KM_Lcd_Write_Str(char *);

#endif /* INC_KM_LCD_H_ */
